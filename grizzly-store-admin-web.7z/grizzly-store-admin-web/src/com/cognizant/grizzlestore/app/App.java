package com.cognizant.grizzlestore.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.grizzlestore.services.LoginService;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;

public class App {

	public static void main(String args[]) {
		// TODO Auto-generated constructor stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-config.xml");
		LoginService service=(LoginService) context.getBean("loginService");
		
		ProductDetails details=context.getBean("productDetails",ProductDetails.class);
		System.out.println(details);
		
		LoginDetails logindetails=context.getBean("LoginDetails",LoginDetails.class);
		System.out.println(details);
		
		details.getProductID();
		//int flag= service.checkUsername("admin");
	}
	
	
	
	

}
