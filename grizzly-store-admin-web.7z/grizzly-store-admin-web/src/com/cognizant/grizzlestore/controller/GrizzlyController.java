package com.cognizant.grizzlestore.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cognizant.grizzlestore.services.ProductService;
import com.cognizant.grizzlystore.model.ProductDetails;

/**
 * Servlet implementation class GrizzlyController
 */
@WebServlet("/GrizzlyController")
public class GrizzlyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrizzlyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		ProductService service= new ProductService();
		ProductService productDAO=new ProductService();
		HttpSession session=request.getSession(false);  
		
		if(session!=null)
		{
		String s=request.getParameter("submit");
		String p=request.getParameter("product");
		//System.out.println(s);
		
		if(s==null && p==null){
			request.setAttribute("productList",productDAO.getProduct());
			RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
			rd.forward(request, response);
			
		}
		else 
			{	if(s!=null) {
				
							if(s.equals("Back")) {
							request.setAttribute("productList",productDAO.getProduct());
								RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
								rd.forward(request, response);
							}
							else if(s.equals("Submit")) {
							//System.out.print("submit");
							String pname=request.getParameter("productname");
							String pcategory=request.getParameter("productcategory");
							String pdescription=request.getParameter("productdesription");
							String pprice=request.getParameter("price");
							String pimage=request.getParameter("productimage");
							String pbrand=request.getParameter("productbrand");
							ProductDetails pd=new ProductDetails();
							pd.setProductName(pname);
							pd.setProductCatagory(pcategory);
							pd.setProductDescription(pdescription);
							pd.setProductImage(pimage);
							pd.setProductPrice(Float.parseFloat(pprice));
							pd.setProductBrand(pbrand);
							
							service.addProduct(pd);
							request.setAttribute("productList",productDAO.getProduct());
							RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
							rd.forward(request, response);
							}
				}
				
				else if(p!=null) {
							String[] e=request.getParameterValues("productid");
							
							if(p.equals("View")) {
								if(e!=null) {
										List<ProductDetails> products=service.viewProduct(e);
										request.setAttribute("productList",products);	
										RequestDispatcher rd=request.getRequestDispatcher("jsp/ViewProject.jsp");
										rd.forward(request, response);
									}
								else {
										request.setAttribute("productList",productDAO.getProduct());
										RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
										rd.forward(request, response);
								}
							}
							else if(p.equals("Block")) {
							
								if(e!=null) {
										service.blockProduct(e);}
								request.setAttribute("productList",productDAO.getProduct());
								RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
								rd.forward(request, response);
								
							}
							else if(p.equals("Remove")) {
								if(e!=null) {
										service.removeProduct(e);}
								request.setAttribute("productList",productDAO.getProduct());
								RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
								rd.forward(request, response);
							}
				}
				else {
							request.setAttribute("productList",productDAO.getProduct());
							RequestDispatcher rd=request.getRequestDispatcher("jsp/GrizzlyStore.jsp");
							rd.forward(request, response);	
				}
			}
		}else
		{
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
		pw.close();
	}

}
