package com.cognizant.grizzlestore.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.grizzlestore.services.IProductDao;
import com.cognizant.grizzlestore.services.LoginService;
import com.cognizant.grizzlestore.services.ProductService;
import com.cognizant.grizzlystore.DAO.LoginDAO;
import com.cognizant.grizzlystore.DAO.ProductDAO;
import com.cognizant.grizzlystore.model.LoginDetails;

/**
 *  implementation class LoginControl
 */
@WebServlet("/LoginControl")
public class LoginControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String uname=request.getParameter("name");
		String pass=request.getParameter("pass");
		
		LoginDetails lv=new LoginDetails();
		lv.setName(uname);
		lv.setPass(pass);
		LoginService ls=new LoginService();
		int n=ls.connect(lv);
		if(n==0) {
			request.setAttribute("error", "Username is incorrect.Please enter correct username and password to login.");
		}
		if(n==1) {
			request.setAttribute("error", "Wrong Password! Try again. (Total attempts 3)");
		}
		if(n==2) {
			request.setAttribute("error","Your account has been locked.");
		}
		if(n==3) {
			//request.setAttribute("user",);
			ProductService s=new ProductService();
			request.setAttribute("productList",s.getProduct());
			
			HttpSession session=request.getSession();  
	        session.setAttribute("name",uname);  
			
			RequestDispatcher rd=request.getRequestDispatcher("/jsp/GrizzlyStore.jsp");
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("/jsp/error.jsp");
			rd.forward(request, response);
		}
		pw.close();
	}

}
