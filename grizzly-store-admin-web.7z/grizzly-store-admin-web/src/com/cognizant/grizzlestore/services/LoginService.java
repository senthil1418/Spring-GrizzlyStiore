package com.cognizant.grizzlestore.services;

import com.cognizant.grizzlystore.DAO.LoginDAO;
import com.cognizant.grizzlystore.model.LoginDetails;

public class LoginService implements ILoginDao {

	public LoginService() {
		// TODO Auto-generated constructor stub
	}
LoginDAO l=new LoginDAO();
	@Override
	public int connect(LoginDetails lv) {
		// TODO Auto-generated method stub
		
		return l.connect(lv);
	}

}
