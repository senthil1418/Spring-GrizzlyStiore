package com.cognizant.grizzlestore.services;

import java.util.List;

import com.cognizant.grizzlystore.DAO.ProductDAO;
import com.cognizant.grizzlystore.DAO.ProductEditDAO;
import com.cognizant.grizzlystore.model.ProductDetails;

public class ProductService implements IProductDao{
	ProductEditDAO p=new ProductEditDAO();
	public ProductService() {
		
		
	}


	@Override
	public List<ProductDetails> getProduct() {
		// TODO Auto-generated method stub
		ProductDAO dao=new ProductDAO();
		return dao.getProduct();
	}


	@Override
	public void addProduct(ProductDetails pd) {
		
		p.addProduct(pd);
		
	}

	@Override
	public void blockProduct(String[] e) {
		
		p.blockProduct(e);
		
	}

	@Override
	public void removeProduct(String[] e) {
		p.removeProduct(e);
		
	}

	@Override
	public List<ProductDetails> viewProduct(String[] e) {
		return p.viewProduct(e);
	}

	

}
