package com.cognizant.grizzlestore.services;

import com.cognizant.grizzlystore.model.LoginDetails;

public interface ILoginDao {
public int connect(LoginDetails lv);
}
