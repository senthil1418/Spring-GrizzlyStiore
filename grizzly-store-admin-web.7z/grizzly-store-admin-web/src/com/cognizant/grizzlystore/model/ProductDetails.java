package com.cognizant.grizzlystore.model;

public class ProductDetails {
	@Override
	public String toString() {
		return "ProductDetails [productID=" + productID + ", productName=" + productName + ", productBrand="
				+ productBrand + ", productCatagory=" + productCatagory + ", productDescription=" + productDescription
				+ ", productPrice=" + productPrice + ", productRating=" + productRating + ", productImage="
				+ productImage + "]";
	}
	private int productID;
	private String productName, productBrand, productCatagory, productDescription;
	private float productPrice, productRating;
	
	private String productImage;
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductCatagory() {
		return productCatagory;
	}
	public void setProductCatagory(String productCatagory) {
		this.productCatagory = productCatagory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	public float getProductRating() {
		return productRating;
	}
	public void setProductRating(float productRating) {
		this.productRating = productRating;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
	
}
