package com.cognizant.grizzlystore.model;

public class LoginDetails {
private static  String name;
private static  String pass;
private static int userId;
public  String getName() {
	return name;
}
public  void setName(String name) {
	LoginDetails.name = name;
}
public  String getPass() {
	return pass;
}
public  void setPass(String pass) {
	LoginDetails.pass = pass;
}

public static int getUserId() {
	return userId;
}
public static void setUserId(int userId) {
	LoginDetails.userId = userId;
}

}
