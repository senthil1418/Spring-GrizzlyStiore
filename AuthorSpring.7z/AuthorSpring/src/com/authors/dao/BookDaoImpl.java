package com.authors.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.authors.models.Book;

public class BookDaoImpl implements BookDao {

	private static Logger logger = LoggerFactory.getLogger(AuthorDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void SaveBook(Book book) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(book);

	}

	@Override
	public List<Book> listBooks() {
		Session session =  sessionFactory.getCurrentSession();
		List<Book> books = session.createQuery("from Book").list();
		return books;
	}

	@Override
	public void removeBook(int id) {
		// TODO Auto-generated method stub
		Book book = (Book) sessionFactory.getCurrentSession().load(Book.class, new Integer(id));
		this.sessionFactory.getCurrentSession().delete(book);
	}

	@Override
	public void updateBook(Book book) {
		this.sessionFactory.getCurrentSession().update(book);
		
	}

	@Override
	public Book findBook(int id) {
		Book book = (Book) sessionFactory.getCurrentSession().load(Book.class, new Integer(id));
		return book;
	}

	@Override
	public List<Book> SearchTitle(String title) {
		Session session =  sessionFactory.getCurrentSession();
		String hql = "select b from Book b where lower(b.title) like :title";
		Query query = session.createQuery(hql);
		query.setString("title", "%" + title.toLowerCase() + "%");
		List<Book> books = query.list();
		return books;
	}
	

}
