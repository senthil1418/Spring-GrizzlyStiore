package com.authors.dao;

import java.util.List;

import com.authors.models.Author;
import com.authors.models.Book;

public interface BookDao {

	public void SaveBook(Book book);
	
	public List<Book> listBooks();
	
	public void removeBook(int id);
	
	public void updateBook(Book book);
	
	public Book findBook(int id);
	
	public List<Book> SearchTitle(String title);
}
