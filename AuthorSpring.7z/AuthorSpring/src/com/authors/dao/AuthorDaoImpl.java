package com.authors.dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.authors.models.Author;

@Repository
public class AuthorDaoImpl implements AuthorDao {

	private static Logger logger = LoggerFactory.getLogger(AuthorDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveAuthor(Author author) {
		logger.info("Starting the persist operation: " + author);
		sessionFactory.getCurrentSession().save(author);
		logger.info("Completed the persist operation " + author);
	}

	@Override
	public List<Author> listAuthors() {
		Session session =  sessionFactory.getCurrentSession();
		logger.info("Fetching authors...");
		List<Author> authors = session.createQuery("from Author").list();
		
		return authors;
	}

	@Override
	public void removeAuthor(int id) {
		logger.info("Deleting author...");
		Author author = (Author) sessionFactory.getCurrentSession().load(Author.class, new Integer(id));
		this.sessionFactory.getCurrentSession().delete(author);
		logger.info("Author deleted..." + author);
		
	}

	@Override
	public void updateAuthor(Author author) {
		logger.info("Updating author...");
		this.sessionFactory.getCurrentSession().update(author);
		logger.info("Updating author complete...");
	}

	@Override
	public Author findAuthor(int id) {
		logger.info("Searching for author...");
		Author author = (Author) this.sessionFactory.getCurrentSession().load(Author.class, new Integer(id));
		//Hibernate.initialize(author.getBooks());
		logger.debug(author.toString());
		return author;
		
	}

	@Override
	public List<Author> searchAuthor(String name) {
		logger.warn("Searching for author...");
		logger.info("Fetching authors...");
		Session session =  sessionFactory.getCurrentSession();
		String hql = "Select a from Author a where lower(a.name) like :keyword";
		Query query = session.createQuery(hql);
		query.setParameter("keyword", "%" + name.toLowerCase() + "%" );
		System.err.println("Name : " + name);
		@SuppressWarnings("unchecked")
		List<Author> authors = query.list();
		return authors;
	}

	

}
