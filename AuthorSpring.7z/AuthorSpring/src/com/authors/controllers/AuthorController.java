package com.authors.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.authors.models.Author;
import com.authors.models.Book;
import com.authors.models.BookViewModel;
import com.authors.service.AuthorService;
import com.sun.org.apache.xml.internal.serializer.utils.SystemIDResolver;

@Controller
public class AuthorController {

	@Autowired
	private AuthorService authorService;

	private Logger logger = LoggerFactory.getLogger(AuthorController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(ModelMap model) {
		logger.warn("Inside the default path.");
		logger.warn("Fetching author list.");
		// model.addAttribute("authors", authorService.listAuthors());
		// model.addAttribute("author", new Author());
		// model.addAttribute("count", authorService.listAUthors().size());
		return "index";
	}

	@RequestMapping(value = "/authors/list", method = RequestMethod.GET)
	public String listAuthors(ModelMap model) {
		List<Author> authors = authorService.listAuthors();
		if (!authors.isEmpty()) {
			model.addAttribute("count", authors.size());
			model.addAttribute("authors", authors);
		} else {
			model.addAttribute("count", 0);
		}
		return "listAuthors";
	}

	@RequestMapping(value = "/authors/search", method = RequestMethod.GET)
	public String searchAuthors(@RequestParam(value = "name") String name, ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside search controller");
		List<Author> authors = authorService.searchAuthor(name);

		System.err.println(authors.size());
		if (!authors.isEmpty()) {
			model.addAttribute("count", authors.size());
			model.addAttribute("authors", authors);
		} else {
			model.addAttribute("count", 0);
		}
		return "listAuthors";
	}

	@RequestMapping(value = "/authors/add", method = RequestMethod.GET)
	public String Author(ModelMap model) {
		model.addAttribute("author", new Author());
		return "addAuthor";
	}

	@RequestMapping(value = "/authors/save", method = RequestMethod.POST)
	public String saveAuthor(@ModelAttribute(value = "author") Author author, ModelMap model) {
		System.err.println("inside save author post");
		try {
			authorService.saveAuthor(author);
			model.addAttribute("commit", true);
		} catch (Exception ex) {
			model.addAttribute("commit", false);
			model.addAttribute("message", ex.getMessage());
		}
		return "addAuthor";
	}

	@RequestMapping(value = "/authors/remove/{id}", method = RequestMethod.GET)
	public String removeAuthor(@PathVariable("id") int id) {
		logger.info("Inside /remove");
		authorService.removeAuthor(id);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/authors/books/{id}", method = RequestMethod.GET)
	public String booksByAuthor(@PathVariable("id") int id, Model map) {
		logger.info("Inside /edit");
		Author a = authorService.findAuthor(id);
		logger.error(a.toString());
		map.addAttribute("books", a.getBooks());
		if (!a.getBooks().isEmpty()) {
			map.addAttribute("count", a.getBooks().size());
		} else {
			map.addAttribute("count", 0);
		}
		return "listBooks";
	}

	@RequestMapping(value = "/authors/edit/{id}", method = RequestMethod.GET)
	public String editAuthor(@PathVariable("id") int id, Model map) {
		logger.info("Inside /edit");
		Author a = authorService.findAuthor(id);
		logger.error(a.toString());
		map.addAttribute("author", a);
		return "editAuthor";
	}
	
	@RequestMapping(value = "/authors/update", method = RequestMethod.POST)
	public String updateAuthor(@ModelAttribute(value = "author") Author author) {
		System.err.println("inside update author post");
		authorService.updateAuthor(author);
		return "redirect:/authors/list";
	}
}
