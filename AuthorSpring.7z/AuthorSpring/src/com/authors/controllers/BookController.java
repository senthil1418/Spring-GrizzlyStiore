package com.authors.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.authors.models.Author;
import com.authors.models.Book;
import com.authors.models.BookViewModel;
import com.authors.service.AuthorService;
import com.authors.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService bookService;

	@Autowired
	private AuthorService authorService;

	@RequestMapping(value = "/books/list", method = RequestMethod.GET)
	public String listBooks(ModelMap model) {
		List<Book> books = bookService.listBooks();
		if (!books.isEmpty()) {
			model.addAttribute("books", books);
			model.addAttribute("count", books.size());
		} else {
			model.addAttribute("count", 0);
		}
		return "listBooks";
	}
	
	
	@RequestMapping(value = "/books/new", method = RequestMethod.GET)
	public String newBook(ModelMap model) {
		System.err.println("inside addNewBookAction");
		try {
			model.addAttribute("book", new BookViewModel());
			List<Author> authors = authorService.listAuthors();
			System.err.println("fetching authors");
			Map<Integer, String> authorsMap = new HashMap<Integer, String>();
			System.err.println("converting authors to map");
			for (Author author : authors) {
				authorsMap.put(author.getId(), author.getName());
			}
			model.addAttribute("authors", authorsMap);
			
		} catch (Exception ex) {
			model.addAttribute("fetch", false);
			model.addAttribute("message", ex.getMessage());
		}
		System.err.println("returning url");
		return "addBook";
	}

	@RequestMapping(value = "/books/save", method = RequestMethod.POST)
	public String addBook(@ModelAttribute(value = "book") BookViewModel model) throws ParseException {
		System.err.println("inside save book");
		Author author = authorService.findAuthor(model.getAuthor());
		System.err.println("author : " + author.getName());
		System.err.println("date : " + model.getPublishDate());
		Book book = new Book();
		book.setAuthor(author);
		book.setTitle(model.getTitle());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date parsedDate = sdf.parse(model.getPublishDate());
		java.sql.Date publishDate = new java.sql.Date(parsedDate.getTime());
		book.setPublishDate(publishDate);
		bookService.saveBook(book);
		return "redirect:/books/list";
	}

	@RequestMapping(value = "/books/search", method = RequestMethod.GET)
	public String searchBooks(@RequestParam(value = "name") String name, ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside search controller");
		List<Book> books = bookService.SearchTitle(name);

		System.err.println(books.size());
		if (!books.isEmpty()) {
			model.addAttribute("count", books.size());
			model.addAttribute("books", books);
		} else {
			model.addAttribute("count", 0);
		}
		return "listBooks";
	}

}
