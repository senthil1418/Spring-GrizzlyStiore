package com.authors.service;

import java.util.List;

import com.authors.models.Author;
import com.authors.models.Book;

public interface BookService {

public void saveBook(Book book);
	
	public List<Book> listBooks();
	
	public void removeBook(int id);
	
	public void updateBook(Book book);
	
	public Book findBook(int id);
	
	public List<Book> SearchTitle(String title);

}
