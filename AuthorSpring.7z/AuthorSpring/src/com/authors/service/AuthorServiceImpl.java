package com.authors.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.authors.dao.AuthorDao;
import com.authors.models.Author;

public class AuthorServiceImpl implements AuthorService {

	@Autowired
	private AuthorDao authorDao;
	
	@Override
	@Transactional
	public void saveAuthor(Author author) {
		authorDao.saveAuthor(author);
	}

	@Override
	@Transactional
	public List<Author> listAuthors() {
		return authorDao.listAuthors();
	}

	@Override
	@Transactional
	public void removeAuthor(int id) {
		authorDao.removeAuthor(id);
	}

	@Override
	@Transactional
	public void updateAuthor(Author author) {
		authorDao.updateAuthor(author);
	}

	@Override
	@Transactional
	public Author findAuthor(int id) {
		return authorDao.findAuthor(id);
	}

	@Override
	@Transactional
	public List<Author> searchAuthor(String name) {
		return authorDao.searchAuthor(name);
	}

}
