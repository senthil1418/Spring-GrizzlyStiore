package com.authors.service;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.authors.models.BookViewModel;

public class NameValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return BookViewModel.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object arg0, Errors errors) {
		BookViewModel book = (BookViewModel) arg0;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "","title is empty");
	}

}
