package com.authors.service;

import java.util.List;

import com.authors.models.Author;

public interface AuthorService {

	public void saveAuthor(Author author);

	public List<Author> listAuthors();

	public void removeAuthor(int id);
	
	public void updateAuthor(Author author);
	
	public Author findAuthor(int id);
	
	public List<Author> searchAuthor(String name);
}
