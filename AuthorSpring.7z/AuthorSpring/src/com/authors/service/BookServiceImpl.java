package com.authors.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.authors.dao.BookDao;
import com.authors.models.Book;

public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;

	@Override
	@Transactional
	public void saveBook(Book book) {
		// TODO Auto-generated method stub
		
		bookDao.SaveBook(book);
	}

	@Override
	@Transactional
	public List<Book> listBooks() {
		// TODO Auto-generated method stub
		return bookDao.listBooks();
	}

	@Override
	@Transactional
	public void removeBook(int id) {
		// TODO Auto-generated method stub
		bookDao.removeBook(id);
		
	}

	@Override
	@Transactional
	public void updateBook(Book book) {
		// TODO Auto-generated method stub
		bookDao.updateBook(book);
		
	}

	@Override
	@Transactional
	public Book findBook(int id) {
		// TODO Auto-generated method stub
		return bookDao.findBook(id);
	}

	@Override
	@Transactional
	public List<Book> SearchTitle(String title) {
		// TODO Auto-generated method stub
		return bookDao.SearchTitle(title);
	}
	
	

	

}
