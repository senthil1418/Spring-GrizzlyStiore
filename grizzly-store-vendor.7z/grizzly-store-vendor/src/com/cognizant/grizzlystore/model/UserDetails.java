package com.cognizant.grizzlystore.model;

public class UserDetails {
private static int uid;
private static String name;
private static String designation;
private static String office;
private static String uimage;

public UserDetails getUserDetails() {
	return new UserDetails();
}
public static String getName() {
	return name;
}

public static void setName(String name) {
	UserDetails.name = name;
}

public static String getDesignation() {
	return designation;
}

public static void setDesignation(String designation) {
	UserDetails.designation = designation;
}

public static String getOffice() {
	return office;
}

public static void setOffice(String office) {
	UserDetails.office = office;
}

public static int getUid() {
	return uid;
}

public static void setUid(int uid) {
	UserDetails.uid = uid;
}
public static String getUimage() {
	return uimage;
}
public static void setUimage(String uimage) {
	UserDetails.uimage = uimage;
}

}
