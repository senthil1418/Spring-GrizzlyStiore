package com.cognizant.grizzlystore.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.UserDetails;
import com.cognizant.grizzlystore.util.ConnectionDB;
public class LoginDAO {
	
	
	private static LoginDAO logindao;
	public static LoginDAO getLoginDAO()
	{
		if(logindao==null)
		logindao=new LoginDAO();
		return logindao;
	}
	private LoginDAO()
	{
		
	}
	

	
public  int connect(LoginDetails lv) {

	Connection con=null;
	PreparedStatement stmt=null;
	ResultSet rs=null;
	String name=lv.getName();
	String pass=lv.getPass();
	
	try {
		con=ConnectionDB.getConnection();
		stmt=con.prepareStatement("Select * from loginstore where username like ? and password like ?;");
		stmt.setString(1, name);
		stmt.setString(2, pass);
		rs=stmt.executeQuery();
	
		if(rs.next())
			{
			if(rs.getInt(4)<3) 
				{
				LoginDetails.setUserId(rs.getInt(3));
				UserDetails.setUid(rs.getInt(3));
				UserProfileDAO.getUserProfileDAO(rs.getInt(3));
				stmt.close();
				rs.close();
				stmt=con.prepareStatement("update loginstore set failedattempt= ? where username like ?;");
				stmt.setInt(1,0);
				stmt.setString(2, name);
				stmt.executeUpdate();
				return 3;
				}
			else return 2;
			}
		else {
			rs.close();
			stmt.close();
			stmt=con.prepareStatement("Select * from loginstore where username like ?;");
			stmt.setString(1, name);
			rs=stmt.executeQuery();
			
			if(rs.next()) {
				if(rs.getInt(4)<3) {
					stmt=con.prepareStatement("update loginstore set failedattempt= ? where username like ?;");
					stmt.setInt(1, rs.getInt(4)+1);
					stmt.setString(2, name);
					stmt.executeUpdate();
					return 1;
					}
				else return 2;
				}
			else return 0;
			}
		
		}
	catch (ClassNotFoundException | SQLException e)
		{
		e.printStackTrace();
		return 0;
		
		}
	finally 
		{
		try {
			if(con!=null) 	con.close();
			if(rs!=null) 	rs.close();
			if(stmt!=null)	stmt.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
}
