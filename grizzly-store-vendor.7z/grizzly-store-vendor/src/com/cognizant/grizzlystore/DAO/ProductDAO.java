package com.cognizant.grizzlystore.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.util.ConnectionDB;
public class ProductDAO {
	
	private static ProductDAO productdao;
	public static ProductDAO getProductDAO()
	{
		if(productdao==null)
		productdao=new ProductDAO();
		return productdao;
	}
	
	private ProductDAO()
	{
		
	}
	
public  List<ProductDetails> getProduct() {
	List<ProductDetails> li=new ArrayList<>();
	Connection con=null;
	PreparedStatement stmt=null;
	ResultSet r=null;
	try {
		
		con=ConnectionDB.getConnection();
		stmt=con.prepareStatement("SELECT * FROM product where product_availability=1;");
		r=stmt.executeQuery();
		while(r.next()) {
		ProductDetails pd=new ProductDetails();
		pd.setProductID(r.getInt(1));
		pd.setProductName(r.getString(2));
		pd.setProductBrand(r.getString(3));
		pd.setProductCatagory(r.getString(4));
		pd.setProductDescription(r.getString(5));
		pd.setProductPrice(r.getFloat(6));
		pd.setProductRating(r.getFloat(7));
		pd.setProductImage(r.getString(9));
		li.add(pd);}
		
		return li;
		}
	catch(Exception e) {
		e.printStackTrace();
		return null;
	}
	finally {
		try {
			if(con!=null) {
				con.close();
			}
			if(stmt!=null)	stmt.close();
			//if(r!=null) r.close();
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
}
