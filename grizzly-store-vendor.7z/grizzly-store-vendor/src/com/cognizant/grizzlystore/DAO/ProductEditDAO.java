package com.cognizant.grizzlystore.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.util.ConnectionDB;


public class ProductEditDAO {

	private static ProductEditDAO producteditdao;
	public static ProductEditDAO getProductEditDAO()
	{
		if(producteditdao==null)
		producteditdao=new ProductEditDAO();
		return producteditdao;
	}
	
	private ProductEditDAO()
	{
		
	}
public  void addProduct(ProductDetails pd) {
					PreparedStatement st = null;
					Connection con = null;
					try {
					con=ConnectionDB.getConnection();
					st=con.prepareStatement("Insert into product(product_name,product_brand,product_category,product_description,product_price,product_image) values(?,?,?,?,?,?);");
					st.setString(1,pd.getProductName() );
					st.setString(2,pd.getProductBrand() );
					st.setString(3,pd.getProductCatagory() );
					st.setString(4,pd.getProductDescription() );
					st.setLong(5,(long) pd.getProductPrice());
					st.setString(6,pd.getProductImage() );
					st.executeUpdate();
					}
					catch(SQLException | ClassNotFoundException e) {
						e.printStackTrace();
					}
					finally {
						try {
							st.close();
							con.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
}

public  void blockProduct(String[] e) {
					PreparedStatement st = null;
					Connection con = null;
					try {
					con=ConnectionDB.getConnection();
					st=con.prepareStatement("update product set product_availability= 0 where product_id=?");
					for(String s: e) {
						st.setString(1, s);
						st.executeUpdate();
					}
					}
					catch(SQLException | ClassNotFoundException ex) {
						ex.printStackTrace();
					}


}

public  void removeProduct(String[] e) {
					PreparedStatement st = null;
					Connection con = null;
				
					try {
					con=ConnectionDB.getConnection();
					st=con.prepareStatement("delete from product where product_id=?");
					for(String s: e) {
						st.setString(1, s);
						st.executeUpdate();
					}
					}
					catch(SQLException | ClassNotFoundException ex) {
						ex.printStackTrace();
					}
					
}

public  List<ProductDetails> viewProduct(String[] e) {
					PreparedStatement st = null;
					Connection con = null;
					ResultSet r=null;
					List<ProductDetails> li=new ArrayList<>();
					try {
						con=ConnectionDB.getConnection();
						st=con.prepareStatement("Select * from product where product_id=?");
						for(String s: e) {
								st.setString(1, s);
								r=st.executeQuery();
								while(r.next()) {
								ProductDetails pd=new ProductDetails();
								pd.setProductID(r.getInt(1));
								pd.setProductName(r.getString(2));
								pd.setProductBrand(r.getString(3));
								pd.setProductCatagory(r.getString(4));
								pd.setProductDescription(r.getString(5));
								pd.setProductPrice(r.getFloat(6));
								pd.setProductRating(r.getFloat(7));
								pd.setProductImage(r.getString(9));
								li.add(pd);
								}
						
					}return li;
					}
					catch(SQLException | ClassNotFoundException ex) {
						ex.printStackTrace();
					}
					
					return null;
					
	}
}
