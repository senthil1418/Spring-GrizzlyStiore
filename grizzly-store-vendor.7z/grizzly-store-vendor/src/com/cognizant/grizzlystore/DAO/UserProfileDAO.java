package com.cognizant.grizzlystore.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.UserDetails;

public class UserProfileDAO {
	
	private static UserProfileDAO userprofiledao;
	
	public static UserProfileDAO getUserProfileDAO(int id)
	{
		if(userprofiledao==null)
			userprofiledao=new UserProfileDAO(id);
		return userprofiledao;
	}
	
	private UserProfileDAO(int id) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			//System.out.println("Entered");
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grizzly_store","root","root");
			stmt=con.prepareStatement("SELECT user_name, user_designation, user_office, user_image FROM userprofile where user_id="+id);
			rs=stmt.executeQuery();
			if(rs.next()) {
				UserDetails.setName(rs.getString(1));
				UserDetails.setDesignation(rs.getString(2));
				UserDetails.setOffice(rs.getString(3));
				UserDetails.setUimage(rs.getString(4));
			}
	} catch(Exception e) {
			e.printStackTrace();
	}
		finally {
			try {
			if(con!=null)
			con.close();
			if(stmt!=null)
				stmt.close();
			if(rs!=null)
				rs.close();
		}catch(Exception e) {}
			}
		}
}
