package com.cognizant.grizzlestore.services;

import com.cognizant.grizzlystore.DAO.LoginDAO;
import com.cognizant.grizzlystore.model.LoginDetails;

public class LoginService implements ILoginDao {

	
	private static LoginService loginservice;
	public static LoginService getLoginService()
	{
		if(loginservice==null)
		loginservice=new LoginService();
		return loginservice;
	}
	
	private LoginService() {
		// TODO Auto-generated constructor stub
	}
LoginDAO l=LoginDAO.getLoginDAO();
	
	public int connect(LoginDetails lv) {
		// TODO Auto-generated method stub
		
		return l.connect(lv);
	}

}
