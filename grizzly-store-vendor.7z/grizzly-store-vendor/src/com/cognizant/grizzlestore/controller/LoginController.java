package com.cognizant.grizzlestore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.grizzlestore.services.LoginService;
import com.cognizant.grizzlestore.services.ProductService;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;

@Controller
public class LoginController {

	public LoginController() {
		// TODO Auto-generated constructor stub
	}

	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String home()
	{
		return "login";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(LoginDetails loginDetails,HttpServletRequest request)
	{
		
		
		LoginService service2=LoginService.getLoginService();
		System.out.println(loginDetails);
		String s=null;
		
		int dblogin=service2.connect(loginDetails);
		if(dblogin==3)
		{
			//LoginDetails ld=new LoginDetails();
			HttpSession session=request.getSession();
			session.setAttribute("user", loginDetails.getName());
			 s="redirect:/app/login3";
			
		}
		else if(dblogin==1)
		{
			s="redirect:/app/login1";
			
			
		}
		else if(dblogin!=3)
		{
			s="redirect:/app/login2";
			
		}
		
		
		
		return s;
	}
	
	
	@RequestMapping(value="/login2",method=RequestMethod.GET)
	public ModelAndView login2(HttpServletRequest request)
	{
		
		ModelAndView modelAndView=new ModelAndView("login");
		request.setAttribute("error","your username and password is wrong!!!");
		
		return modelAndView;
		
	}
	@RequestMapping(value="/login1",method=RequestMethod.GET)
	public ModelAndView login1(HttpServletRequest request)
	{
		
		ModelAndView modelAndView=new ModelAndView("login");
		request.setAttribute("error","your password is wrong!!!");
		
		return modelAndView;
		
	}
	@RequestMapping(value="/login3",method=RequestMethod.GET)
	public ModelAndView login3()
	{
		ProductService service= ProductService.getProductService();
		List<ProductDetails> pd=service.getProduct();
		System.out.println(pd);
		ModelAndView modelAndView=new ModelAndView("GrizzlyStore");
		modelAndView.addObject("productList",pd);
		
		return modelAndView;
		
	}
	
	
	
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String addproduct()
	{
		return "AddProduct";
	}
	
	
	@RequestMapping(value="/back",method=RequestMethod.POST)
	public ModelAndView back()
	{
		ProductService service= ProductService.getProductService();
		ModelAndView modelAndView=new ModelAndView("GrizzlyStore");
		List<ProductDetails> pd2=service.getProduct();
		modelAndView.addObject("productList",pd2);
		return modelAndView;
	}
	
	
	@RequestMapping(value="/addproddetails",method=RequestMethod.POST)
	public String addproductdetails(ProductDetails pd)
	{
		ProductService service= ProductService.getProductService();
		
		service.addProduct(pd);
		return "redirect:/app/addprod";
	}
	
	@RequestMapping(value="/addprod",method=RequestMethod.GET)
	public ModelAndView addprod(ProductDetails pd)
	{
		
		ProductService service= ProductService.getProductService();
		ModelAndView modelAndView= new ModelAndView();
		
		
		List<ProductDetails> pd2=service.getProduct();
		
		modelAndView=new ModelAndView("GrizzlyStore");
		modelAndView.addObject("productList",pd2);
		
		return modelAndView;
		
	}
	@RequestMapping(value="/viewproddetails",method=RequestMethod.POST)
	public ModelAndView viewproductdetails(String[] productid,ProductDetails pd,String product)
	{
		ProductService service= ProductService.getProductService();
		ModelAndView modelAndView= null;
		
		
		if(productid!=null)
		{
			if(product.equals("View"))
			{
				service.viewProduct(productid);
				List<ProductDetails> pd3=service.viewProduct(productid);
				modelAndView=new ModelAndView("ViewProject");
				modelAndView.addObject("productList",pd3);
			}
			else if(product.equals("Block"))
			{
				service.blockProduct(productid);
				modelAndView=new ModelAndView("GrizzlyStore");
				List<ProductDetails> pd2=service.getProduct();
				modelAndView.addObject("productList",pd2);
			}
			else if(product.equals("Remove"))
			{
				service.removeProduct(productid);
				modelAndView=new ModelAndView("GrizzlyStore");
				List<ProductDetails> pd2=service.getProduct();
				modelAndView.addObject("productList",pd2);
			}
		}
		else
		{
			modelAndView=new ModelAndView("GrizzlyStore");
			List<ProductDetails> pd2=service.getProduct();
			modelAndView.addObject("productList",pd2);
		}
		
		
		
		return modelAndView;
	}
	@RequestMapping(value="/logout",method=RequestMethod.POST)
	public ModelAndView logout(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView("login");
		HttpSession session=request.getSession(false);
		session.invalidate();
		System.out.println(session);
		return modelAndView;
	}
	
}
