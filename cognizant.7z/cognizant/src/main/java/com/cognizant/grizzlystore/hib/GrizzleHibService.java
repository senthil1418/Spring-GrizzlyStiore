package com.cognizant.grizzlystore.hib;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;

@Service(value="grizzleHibService")
public class GrizzleHibService implements IGrizzleStore{

	private GrizzleHibService() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Autowired
	 IGrizzleStore grizzleDao;
	   
	  
	@Override
	public int connect(LoginDetails lv) {
		// TODO Auto-generated method stub
		return grizzleDao.connect(lv);
	}
	
	@Override
	public List<ProductDetails> getProduct() {
		// TODO Auto-generated method stub
		return grizzleDao.getProduct();
	}
	@Override
	public void addProduct(ProductDetails pd) {
		// TODO Auto-generated method stub
		grizzleDao.addProduct(pd);
		
	}
	@Override
	public void blockProduct(String[] e) {
		// TODO Auto-generated method stub
		grizzleDao.blockProduct(e);
		
	}
	@Override
	public void removeProduct(String[] e) {
		// TODO Auto-generated method stub
		grizzleDao.removeProduct(e);
		
	}
	@Override
	public List<ProductDetails> viewProduct(String[] e) {
		// TODO Auto-generated method stub
		
		return grizzleDao.viewProduct(e);
	}
	@Override
	public void editProduct(ProductDetails pd, String s) {
		// TODO Auto-generated method stub
		grizzleDao.editProduct(pd, s);
		
	}

}
