package com.cognizant.grizzlystore.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="userprofile")
public class UserDetails {
	
	public void UserDet(int uid, String name, String designation, String uimage,String office) {
		
		 this.uid = uid;
		this.name = name;
		this.designation = designation;
		this.uimage = uimage;
		this.office=office;
	}
	//private static UserDetails userdetails;
	
	private UserDetails() {
		
		// TODO Auto-generated constructor stub
	}
	
	private static UserDetails  userdetails=null;
	public static UserDetails getUserDetails()
	{
		if(userdetails==null)
		userdetails=new UserDetails();
		return userdetails;
	}
	
	
	/*public UserDetails getUserDetails() {
		return new UserDetails(uid,name,designation,uimage);
	}*/
	
@Id
@Column(name="user_id")
private  int uid;

@Column(name="user_name")
private  String name;

@Column(name="user_designation")
private  String designation;

@Column(name="user_office")
private  String office;

@Column(name="user_image")
private  String uimage;

public int getUid() {
	return uid;
}

public void setUid(int uid) {
	this.uid = uid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDesignation() {
	return designation;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

public  String getOffice() {
	return office;
}

public  void setOffice(String office) {
	this.office = office;
}

public String getUimage() {
	return uimage;
}

public void setUimage(String uimage) {
	this.uimage = uimage;
}


/*public static UserDetails getUserDetails()
{
	if(userdetails==null)
	userdetails=new UserDetails();
	return userdetails;
}*/




}
