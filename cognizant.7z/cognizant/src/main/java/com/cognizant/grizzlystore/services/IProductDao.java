package com.cognizant.grizzlystore.services;

import java.util.List;

import com.cognizant.grizzlystore.model.ProductDetails;

public interface IProductDao {
	

	public List<ProductDetails> getProduct();
	public  void addProduct(ProductDetails pd);
	public  void blockProduct(String[] e);
	public  void removeProduct(String[] e);
	public  List<ProductDetails> viewProduct(String[] e);
	public  void editProduct(ProductDetails pd,String s);
 
}
