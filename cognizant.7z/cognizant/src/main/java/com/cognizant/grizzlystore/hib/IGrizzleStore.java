package com.cognizant.grizzlystore.hib;

import com.cognizant.grizzlystore.services.ILoginDao;
import com.cognizant.grizzlystore.services.IProductDao;

public interface IGrizzleStore extends ILoginDao,IProductDao{
	
	

}
