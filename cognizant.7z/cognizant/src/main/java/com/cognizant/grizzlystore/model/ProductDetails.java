package com.cognizant.grizzlystore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class ProductDetails {
	@Override
	public String toString() {
		return "ProductDetails [productID=" + productID + ", productName=" + productName + ", productBrand="
				+ productBrand + ", productCatagory=" + productCatagory + ", productDescription=" + productDescription
				+ ", productPrice=" + productPrice + ", productRating=" + productRating + ", productImage="
				+ productImage + "]";
	}
	
	private  ProductDetails() {
		// TODO Auto-generated constructor stub
	}
	
	private static ProductDetails pd=null;
	public static ProductDetails getProductDetails()
	{
		if(pd==null)
		pd=new ProductDetails();
		return pd;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Product_id")
	private int productID;
	
	
	@Column(name="product_name")
	private String productName;
	
	
	@Column(name="product_brand")
	private String productBrand;
	
	
	@Column(name="product_category")
	private String productCatagory;
	
	@Column(name="product_description")
	private String  productDescription;
	
	@Column(name="product_price")
	private float productPrice ;
	
	@Column(name="product_rating")
	private float productRating;
	
	@Column(name="product_image")
	private String productImage;
	
	@Column(name="product_availability")
	private int productavailability;
	
	public int getProductavailability() {
		return productavailability;
	}
	public void setProductavailability(int productavailability) {
		this.productavailability = productavailability;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductCatagory() {
		return productCatagory;
	}
	public void setProductCatagory(String productCatagory) {
		this.productCatagory = productCatagory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	public float getProductRating() {
		return productRating;
	}
	public void setProductRating(float productRating) {
		this.productRating = productRating;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
	
}
