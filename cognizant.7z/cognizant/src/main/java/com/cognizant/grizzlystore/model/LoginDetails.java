package com.cognizant.grizzlystore.model;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="loginstore")
public class LoginDetails {

@Id
@Column(name="username")
private   String name;


@Override
public String toString() {
	return "LoginDetails [name=" + name + ", pass=" + pass + ", userId=" + userId + ", failedattempt=" + failedattempt
			+ "]";
}

public LoginDetails(String name, String pass, int userId, int failedattempt) {
	super();
	this.name = name;
	this.pass = pass;
	this.userId = userId;
	this.failedattempt = failedattempt;
}

public LoginDetails() {
	super();
	// TODO Auto-generated constructor stub
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPass() {
	return pass;
}

public void setPass(String pass) {
	this.pass = pass;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public int getFailedattempt() {
	return failedattempt;
}

public void setFailedattempt(int failedattempt) {
	this.failedattempt = failedattempt;
}

@Column(name="password")
private   String pass;


//@GeneratedValue(strategy=GenerationType.IDENTITY)

@Column(name="user_id")
private int userId;

@Column(name="failedattempt")
private  int failedattempt;



}
