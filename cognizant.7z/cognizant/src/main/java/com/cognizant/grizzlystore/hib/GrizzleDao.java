package com.cognizant.grizzlystore.hib;
import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.model.UserDetails;


@Component
public class GrizzleDao implements IGrizzleStore{

	private GrizzleDao() {
		// TODO Auto-generated constructor stub
	}

	static Logger logger=Logger.getLogger(GrizzleDao.class);
	
	@PersistenceContext
	public EntityManager entityManager;
	
	
	@Override
	public int connect(LoginDetails lv) {
		// TODO Auto-generated method stub
		
		int flag=1;
		
		String hql="Select l.name , l.pass, l.userId from LoginDetails l where l.name=? and l.pass=? ";
		Query query=	entityManager.createQuery(hql);
		query.setParameter(0, lv.getName());
		query.setParameter(1, lv.getPass());

		//System.out.println("Resuklt"+query.getSingleResult());
		List<Object[]> l=  query.getResultList();
		Object un= l.get(0)[0];
		Object pas = l.get(0)[1];
		
		if(!l.isEmpty())
		{
		
		if(un!=null && pas!=null) {
			System.out.println("Logged in");
			Object id=l.get(0)[2];
			String hql2="Select l.uid , l.name , l.designation , l.office , l.uimage  from UserDetails l where l.uid=? ";
			Query query2=	entityManager.createQuery(hql2);
			query2.setParameter(0, (int)id);
			
			UserDetails  ud=UserDetails.getUserDetails();
			List<Object[]> l2=  query2.getResultList();
			
				ud.setUid((int)l2.get(0)[0]);
			    ud.setName((String)l2.get(0)[1]);
			    ud.setDesignation((String)l2.get(0)[2]);
			    ud.setOffice((String)l2.get(0)[3]);
			    ud.setUimage((String)l2.get(0)[4]);
			
			flag=3;
			
		}else {
			System.out.println("User not available");
			
		}
		}
		//entityManager.close();
			return flag;
		
	}

	@Override
	public List<ProductDetails> getProduct() {
		// TODO Auto-generated method stub
		List<ProductDetails> li=null;
		String hql="Select l from ProductDetails l where l.productavailability=?";
		TypedQuery<ProductDetails> query=entityManager.createQuery(hql,ProductDetails.class);
		query.setParameter(0, 1);
		li=query.getResultList();
		
		
		return li;
	}
    
	@Transactional
	@Override
	public void addProduct(ProductDetails pd) {
		// TODO Auto-generated method stub
		pd.setProductavailability(1);
		entityManager.merge(pd);
		
		
	}
    
	@Transactional
	@Override
	public void blockProduct(String[] e) {
		for(String s:e)
		{
			int id=Integer.valueOf(s);
		ProductDetails details=	entityManager.find(ProductDetails.class,id);
		details.setProductavailability(0);
		}
	}

	@Transactional
	@Override
	public void removeProduct(String[] e) {
		// TODO Auto-generated method stub
		for(String s:e)
		{
			int id=Integer.valueOf(s);
		ProductDetails details=	entityManager.find(ProductDetails.class,id);
		entityManager.remove(details);
		}
		
	}

	@Transactional
	@Override
	public List<ProductDetails> viewProduct(String[] e) {
		// TODO Auto-generated method stub
		List<ProductDetails> li=new ArrayList<ProductDetails>();
		
		for(String s:e)
		{
			int id=Integer.valueOf(s);
			ProductDetails details=	entityManager.find(ProductDetails.class,id);
			li.add(details);
			
	    
		
		}
		
		
		return li;
	}

	@Transactional
	@Override
	public void editProduct(ProductDetails pd, String s) {
		// TODO Auto-generated method stub
		int id=Integer.valueOf(s);
		String img="";
		//Query query=entityManager.createQuery("Select l.productImage from ProductDetails l where productID=?");
		//query.setParameter(0, (int)id);
		//List<Object[]> l=  query.getResultList();
		ProductDetails details=	entityManager.find(ProductDetails.class,id);
		pd.setProductavailability(1);
		
		if(!(pd.getProductImage().isEmpty()))
		{
		entityManager.merge(pd);
		}
		else
		{
			//details.setProductImage(pd.getProductImage());
			//pd.setProductImage((String)l.get(0)[0]);
			entityManager.merge(details);
		}
		
		
	}
	
	
	

}
